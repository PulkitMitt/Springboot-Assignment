package com.example.UserMnagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserMnagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
