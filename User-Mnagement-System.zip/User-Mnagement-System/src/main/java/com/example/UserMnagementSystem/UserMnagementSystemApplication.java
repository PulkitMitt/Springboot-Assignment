package com.example.UserMnagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserMnagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserMnagementSystemApplication.class, args);
	}

}
