package com.geekster.UserManagementUsingValidations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementUsingValidationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
