package com.geekster.UserManagementUsingValidations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserManagementUsingValidationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserManagementUsingValidationsApplication.class, args);
	}

}
