package com.example.UserManagementProjectGeekster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementProjectGeeksterApplicationTests {

	@Test
	void contextLoads() {
	}

}
